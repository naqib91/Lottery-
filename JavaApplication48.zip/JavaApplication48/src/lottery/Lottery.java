
package lottery;

import java.util.Scanner;

public class Lottery {

    public static void main(String[] args) {
      Scanner n = new Scanner (System.in);
    int lot = (int)((Math.random()*90)+10);
    int lot1,lot2,guss1,guss2;
    lot1 = lot/10;
    lot2 = lot%10;
        System.out.println("Type two numbers");
        int guss = n.nextInt();
        guss1 = guss/10;
        guss2 = guss%10;
        System.out.println("The lottery number is  " + lot );
        if (guss == lot) {System.out.println("You won 10000");}
        else if (guss1 == lot2 && guss2 == lot1){System.out.println("You won 3000");}
        else if (guss1 == lot1 || guss1 == lot2 || guss2 == lot1 || guss2 == lot2){System.out.println("You won 1000");}
        else System.out.println("Sorry, noo , money");
        
        
      
        
    }
}